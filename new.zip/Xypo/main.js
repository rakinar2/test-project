  //-------Navbar--------//
  
  var sideNav = document.getElementById("sideNav");
  var menuBtn = document.getElementById("menuBtn");
  
  sideNav.style.right = "-350px";
  
  menuBtn.onclick = function(){
    if(sideNav.style.right == "-350px"){
      sideNav.style.right = "0";
    }
    else {
      sideNav.style.right = "-350px";
    }
  };
  
  
  
  
  
  
  